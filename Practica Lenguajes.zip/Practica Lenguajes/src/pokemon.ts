export interface Pokemon {
  nombre: string;
  tipo: string;
  salud: number;
  ataque: number;
  defensa: number;
  iv: number;
}